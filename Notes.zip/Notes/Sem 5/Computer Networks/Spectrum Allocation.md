
### Radio waves
---
- 3KHz -> 1GHz
- low frequency range
- omni-directional antennae
- example: FM Radio, TV, ...

### Micro waves
---
- 1GHz -> 40GHz
- medium to high frequency range
- omni-directional in medium range, phased antennae for high frequencies
- example: WiFi
	- 2.4 GHz -> unlicensed ISM (Industrial Scientific Medical) band
	- 5 GHz -> licensed

### Infrared
---
- example: TV Remote, wireless keyboard and mouse, ...

