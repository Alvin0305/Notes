### Fermat's Little Theorem
---
- If p is a prime number, then for all integer a < p, 
$$
a^{p-1} = 1 \text{ mod p}
$$

### Masters Theorem
---
...