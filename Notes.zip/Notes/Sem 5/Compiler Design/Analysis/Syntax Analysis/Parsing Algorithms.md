- Universal Algorithm => CYK Algorithm
	- Can parse any grammar in $O(n^3)$ time
- Compilers commonly use top down or bottom up parsing methods

## Top Down Parsing
---
![[Top Down Parsing Algorithms]]
## Bottom Up Parsing
---
![[Bottom Up Parsing Algorithms]]
