- [[Analysis]] (Front End)
	- [[Lexical Analysis]]
	- [[Syntax Analysis]]
	- [[Semantic Analysis]]
- [[Synthesis]] (Back End)
	- intermediate code generation
	- code optimization
	- code generation

>[!tip] Steps of Compilation
>Source Code -> `Front End` -> [[Sem 5/Compiler Design/Concepts#Intermediate Representation (IR)|IR]] + [[Sem 5/Compiler Design/Concepts#Symbol Table|Symbol Table]] -> `Back End` -> Target Code

![[Analysis]]

![[Synthesis]]